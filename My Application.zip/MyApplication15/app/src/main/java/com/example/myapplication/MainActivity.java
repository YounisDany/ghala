package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.example.myapplication.BodyCareActivity;
import com.example.myapplication.HairCareActivity;
import com.example.myapplication.SkinCareActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // تأكد من أن هذا هو ملف XML الرئيسي

        // ابحث عن العناصر التي تريد إضافتها كأزرار
        LinearLayout skinCareButton = findViewById(R.id.skin_care_button);
        LinearLayout bodyCareButton = findViewById(R.id.body_care_button);
        LinearLayout hairCareButton = findViewById(R.id.hair_care_button);

        // عند الضغط على العناية بالبشرة، يتم فتح صفحة SkinCareActivity
        skinCareButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SkinCareActivity.class);
            startActivity(intent);
        });

        // عند الضغط على العناية بالجسم، يتم فتح صفحة BodyCareActivity
        bodyCareButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, BodyCareActivity.class);
            startActivity(intent);
        });

        // عند الضغط على العناية بالشعر، يتم فتح صفحة HairCareActivity
        hairCareButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, HairCareActivity.class);
            startActivity(intent);
        });
    }
}
